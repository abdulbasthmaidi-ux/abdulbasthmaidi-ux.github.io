import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { ArrowRight, CheckCircle2, Loader2, Mail } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function ServiceDetail() {
  const params = useParams();
  const [, navigate] = useLocation();
  const slug = params.slug as string;

  const { data: service, isLoading } = trpc.services.bySlug.useQuery(slug);
  const { data: categories = [] } = trpc.services.categories.useQuery();

  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    subject: `استفسار عن خدمة: ${service?.name || ""}`,
    message: "",
  });

  const sendContactMutation = trpc.contact.send.useMutation({
    onSuccess: () => {
      toast.success("تم إرسال رسالتك بنجاح!");
      setContactForm({
        name: "",
        email: "",
        subject: `استفسار عن خدمة: ${service?.name || ""}`,
        message: "",
      });
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ في إرسال الرسالة");
    },
  });

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendContactMutation.mutate(contactForm);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin text-accent" size={40} />
      </div>
    );
  }

  if (!service) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">الخدمة غير موجودة</h1>
          <p className="text-muted-foreground mb-8">
            عذراً، لم نتمكن من العثور على الخدمة المطلوبة
          </p>
          <Button onClick={() => navigate("/")} className="bg-accent">
            العودة للصفحة الرئيسية
          </Button>
        </div>
      </div>
    );
  }

  const category = categories.find((c) => c.id === service.categoryId);
  const features = service.features ? JSON.parse(service.features) : [];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="text-2xl font-bold text-accent">BASCOE</div>
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="text-foreground hover:text-accent"
          >
            <ArrowRight size={20} className="ml-2" />
            العودة
          </Button>
        </div>
      </nav>

      {/* Breadcrumb */}
      <div className="bg-card/50 border-b border-border">
        <div className="container py-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <button onClick={() => navigate("/")} className="hover:text-accent">
              الرئيسية
            </button>
            <span>/</span>
            <button onClick={() => navigate("/")} className="hover:text-accent">
              الخدمات
            </button>
            <span>/</span>
            <span className="text-foreground">{service.name}</span>
          </div>
        </div>
      </div>

      {/* Service Header */}
      <section className="py-12 md:py-20 bg-gradient-to-br from-accent/10 via-background to-background">
        <div className="container">
          <div className="max-w-3xl">
            <div className="mb-4">
              {category && (
                <span className="inline-block px-4 py-2 bg-accent/20 text-accent rounded-full text-sm font-semibold">
                  {category.name}
                </span>
              )}
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 text-foreground">
              {service.name}
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed mb-8">
              {service.description}
            </p>
            {service.startingPrice && (
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold text-accent">
                  {service.startingPrice}
                </span>
                <span className="text-muted-foreground">السعر الأساسي</span>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Features Section */}
      {features.length > 0 && (
        <section className="py-16 md:py-24">
          <div className="container">
            <h2 className="text-4xl font-bold mb-12 text-center">المميزات الرئيسية</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
              {features.map((feature: string, index: number) => (
                <div key={index} className="flex gap-4">
                  <div className="flex-shrink-0">
                    <CheckCircle2 size={24} className="text-accent mt-1" />
                  </div>
                  <div>
                    <p className="text-lg text-foreground">{feature}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Service Details */}
      <section className="py-16 md:py-24 bg-card/50">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-4xl font-bold mb-8">تفاصيل الخدمة</h2>
            <Card className="p-8 border border-border">
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold mb-2 text-foreground">
                    ما هي هذه الخدمة؟
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {service.description}
                  </p>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2 text-foreground">
                    من يستفيد من هذه الخدمة؟
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    هذه الخدمة مناسبة للشركات والأفراد الذين يسعون لتحسين وجودهم الرقمي وتحقيق أهدافهم التجارية.
                  </p>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2 text-foreground">
                    كيف نقدم هذه الخدمة؟
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    نستخدم أحدث التقنيات والأدوات المتاحة لضمان تقديم خدمة عالية الجودة وموثوقة تلبي احتياجاتك بشكل كامل.
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold mb-4">هل أنت مهتم؟</h2>
              <p className="text-lg text-muted-foreground">
                تواصل معنا الآن للحصول على عرض مخصص لاحتياجاتك
              </p>
            </div>

            <Card className="p-8 border border-border">
              <form onSubmit={handleContactSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-foreground">
                      الاسم
                    </label>
                    <input
                      type="text"
                      placeholder="اسمك الكامل"
                      value={contactForm.name}
                      onChange={(e) =>
                        setContactForm({ ...contactForm, name: e.target.value })
                      }
                      className="w-full px-4 py-2 rounded-lg border border-border bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-foreground">
                      البريد الإلكتروني
                    </label>
                    <input
                      type="email"
                      placeholder="بريدك الإلكتروني"
                      value={contactForm.email}
                      onChange={(e) =>
                        setContactForm({ ...contactForm, email: e.target.value })
                      }
                      className="w-full px-4 py-2 rounded-lg border border-border bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2 text-foreground">
                    الموضوع
                  </label>
                  <input
                    type="text"
                    placeholder={contactForm.subject}
                    value={contactForm.subject}
                    onChange={(e) =>
                      setContactForm({ ...contactForm, subject: e.target.value })
                    }
                    className="w-full px-4 py-2 rounded-lg border border-border bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2 text-foreground">
                    الرسالة
                  </label>
                  <textarea
                    placeholder="اكتب رسالتك هنا..."
                    rows={6}
                    value={contactForm.message}
                    onChange={(e) =>
                      setContactForm({ ...contactForm, message: e.target.value })
                    }
                    className="w-full px-4 py-2 rounded-lg border border-border bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent resize-none"
                    required
                  />
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full bg-accent text-accent-foreground hover:shadow-lg"
                  disabled={sendContactMutation.isPending}
                >
                  {sendContactMutation.isPending ? (
                    "جاري الإرسال..."
                  ) : (
                    <>
                      <Mail size={20} className="ml-2" />
                      إرسال الرسالة
                    </>
                  )}
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="container text-center text-muted-foreground">
          <p>&copy; 2026 BASCOE. جميع الحقوق محفوظة.</p>
        </div>
      </footer>
    </div>
  );
}
