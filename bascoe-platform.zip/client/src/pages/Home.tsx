import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Menu, X, Search, ArrowRight, CheckCircle2, Mail } from "lucide-react";
import { toast } from "sonner";

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  // Fetch categories and services
  const { data: categories = [] } = trpc.services.categories.useQuery();
  const { data: services = [] } = trpc.services.list.useQuery({
    categoryId: selectedCategory || undefined,
  });

  const sendContactMutation = trpc.contact.send.useMutation({
    onSuccess: () => {
      toast.success("تم إرسال رسالتك بنجاح!");
      setContactForm({ name: "", email: "", subject: "", message: "" });
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ في إرسال الرسالة");
    },
  });

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendContactMutation.mutate(contactForm);
  };

  // Filter services by search query
  const filteredServices = services.filter(
    (service) =>
      service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="text-2xl font-bold text-accent">BASCOE</div>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex gap-8 items-center">
            <a href="#services" className="text-foreground hover:text-accent transition">
              الخدمات
            </a>
            <a href="#about" className="text-foreground hover:text-accent transition">
              من نحن
            </a>
            <a href="#contact" className="text-foreground hover:text-accent transition">
              التواصل
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-card border-t border-border p-4 space-y-4">
            <a href="#services" className="block text-foreground hover:text-accent">
              الخدمات
            </a>
            <a href="#about" className="block text-foreground hover:text-accent">
              من نحن
            </a>
            <a href="#contact" className="block text-foreground hover:text-accent">
              التواصل
            </a>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-accent/10 via-background to-background py-20 md:py-32">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center animate-fade-in-up">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 text-foreground">
              منصة <span className="text-accent">BASCOE</span>
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 leading-relaxed">
              حلول رقمية متكاملة لتحويل أحلامك إلى واقع. نقدم أكثر من 100 خدمة برمجية واحترافية
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-accent text-accent-foreground hover:shadow-lg hover:scale-105"
                onClick={() => document.getElementById("services")?.scrollIntoView({ behavior: "smooth" })}
              >
                استكشف الخدمات
                <ArrowRight className="ml-2" size={20} />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
              >
                تواصل معنا
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 md:py-32">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">خدماتنا المتميزة</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              مجموعة شاملة من الخدمات الرقمية المتخصصة لتلبية احتياجات عملك
            </p>
          </div>

          {/* Search Bar */}
          <div className="mb-8 flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute right-3 top-3 text-muted-foreground" size={20} />
              <Input
                placeholder="ابحث عن خدمة..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-4 pr-10"
              />
            </div>
          </div>

          {/* Category Filter */}
          <div className="mb-12 flex flex-wrap gap-3">
            <Button
              variant={selectedCategory === null ? "default" : "outline"}
              onClick={() => setSelectedCategory(null)}
              className="rounded-full"
            >
              الكل
            </Button>
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                onClick={() => setSelectedCategory(category.id)}
                className="rounded-full"
              >
                {category.name}
              </Button>
            ))}
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredServices.length > 0 ? (
              filteredServices.map((service, index) => (
                <Card
                  key={service.id}
                  className="p-6 hover:shadow-lg hover:scale-105 transition-all duration-300 border border-border hover:border-accent/50 animate-fade-in-up"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <div className="mb-4">
                    <h3 className="text-xl font-semibold text-foreground mb-2">
                      {service.name}
                    </h3>
                    <p className="text-muted-foreground text-sm line-clamp-3">
                      {service.description}
                    </p>
                  </div>

                  {service.features && (
                    <div className="mb-4 space-y-2">
                      {JSON.parse(service.features || "[]")
                        .slice(0, 3)
                        .map((feature: string, idx: number) => (
                          <div key={idx} className="flex items-start gap-2">
                            <CheckCircle2 size={16} className="text-accent mt-0.5 flex-shrink-0" />
                            <span className="text-sm text-muted-foreground">{feature}</span>
                          </div>
                        ))}
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-4 border-t border-border">
                    {service.startingPrice && (
                      <span className="text-lg font-semibold text-accent">
                        من {service.startingPrice}
                      </span>
                    )}
                    <a href={`/service/${service.slug}`}>
                      <Button size="sm" variant="ghost" className="text-accent hover:bg-accent/10">
                        تفاصيل أكثر
                        <ArrowRight size={16} className="ml-1" />
                      </Button>
                    </a>
                  </div>
                </Card>
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <p className="text-muted-foreground text-lg">لم يتم العثور على خدمات</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 md:py-32 bg-card/50">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold mb-8 text-center">من نحن</h2>
            <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
              <p>
                منصة <span className="text-accent font-semibold">BASCOE</span> هي وجهتك الموثوقة لجميع احتياجاتك الرقمية والبرمجية. نحن نجمع بين الخبرة العميقة والابتكار المستمر لتقديم حلول متقدمة وموثوقة.
              </p>
              <p>
                مع فريق من المتخصصين ذوي الخبرة العالية، نقدم أكثر من 100 خدمة متنوعة تغطي جميع جوانب التطوير الرقمي والتسويق الإلكتروني والحلول التقنية المتقدمة.
              </p>
              <p>
                رؤيتنا هي أن نكون الشريك الأول الموثوق به للشركات والأفراد الذين يسعون لتحويل أفكارهم إلى مشاريع ناجحة وقابلة للنمو.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 md:py-32">
        <div className="container">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl font-bold mb-4">تواصل معنا</h2>
              <p className="text-lg text-muted-foreground">
                لديك استفسار؟ نحن هنا للإجابة على جميع أسئلتك
              </p>
            </div>

            <Card className="p-8 border border-border">
              <form onSubmit={handleContactSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-foreground">
                      الاسم
                    </label>
                    <Input
                      placeholder="اسمك الكامل"
                      value={contactForm.name}
                      onChange={(e) =>
                        setContactForm({ ...contactForm, name: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-foreground">
                      البريد الإلكتروني
                    </label>
                    <Input
                      type="email"
                      placeholder="بريدك الإلكتروني"
                      value={contactForm.email}
                      onChange={(e) =>
                        setContactForm({ ...contactForm, email: e.target.value })
                      }
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2 text-foreground">
                    الموضوع
                  </label>
                  <Input
                    placeholder="موضوع الرسالة"
                    value={contactForm.subject}
                    onChange={(e) =>
                      setContactForm({ ...contactForm, subject: e.target.value })
                    }
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2 text-foreground">
                    الرسالة
                  </label>
                  <Textarea
                    placeholder="اكتب رسالتك هنا..."
                    rows={6}
                    value={contactForm.message}
                    onChange={(e) =>
                      setContactForm({ ...contactForm, message: e.target.value })
                    }
                    required
                  />
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full bg-accent text-accent-foreground hover:shadow-lg"
                  disabled={sendContactMutation.isPending}
                >
                  {sendContactMutation.isPending ? (
                    "جاري الإرسال..."
                  ) : (
                    <>
                      <Mail size={20} className="ml-2" />
                      إرسال الرسالة
                    </>
                  )}
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-xl font-bold text-accent mb-4">BASCOE</h3>
              <p className="text-muted-foreground">
                منصة متكاملة لجميع احتياجاتك الرقمية
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-foreground">الروابط</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#services" className="hover:text-accent transition">الخدمات</a></li>
                <li><a href="#about" className="hover:text-accent transition">من نحن</a></li>
                <li><a href="#contact" className="hover:text-accent transition">التواصل</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-foreground">الفئات</h4>
              <ul className="space-y-2 text-muted-foreground">
                {categories.slice(0, 3).map((cat) => (
                  <li key={cat.id}>{cat.name}</li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-foreground">التواصل</h4>
              <p className="text-muted-foreground">
                <a href="mailto:info@bascoe.com" className="hover:text-accent transition">
                  info@bascoe.com
                </a>
              </p>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-muted-foreground">
            <p>&copy; 2026 BASCOE. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
