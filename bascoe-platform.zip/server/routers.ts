import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { getAllServiceCategories, getAllServices, getServiceBySlug, createContactMessage } from "./db";
import { z } from "zod";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  services: router({
    categories: publicProcedure.query(async () => {
      return getAllServiceCategories();
    }),
    list: publicProcedure
      .input(z.object({ categoryId: z.number().optional() }).optional())
      .query(async ({ input }) => {
        return getAllServices(input?.categoryId);
      }),
    bySlug: publicProcedure
      .input(z.string())
      .query(async ({ input }) => {
        return getServiceBySlug(input);
      }),
  }),

  contact: router({
    send: publicProcedure
      .input(z.object({
        name: z.string().min(1, "الاسم مطلوب"),
        email: z.string().email("بريد إلكتروني غير صحيح"),
        subject: z.string().min(1, "الموضوع مطلوب"),
        message: z.string().min(10, "الرسالة يجب أن تكون 10 أحرف على الأقل"),
      }))
      .mutation(async ({ input }) => {
        await createContactMessage({
          name: input.name,
          email: input.email,
          subject: input.subject,
          message: input.message,
          status: "new",
        });
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
