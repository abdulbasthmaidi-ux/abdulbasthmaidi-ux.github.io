import mysql from 'mysql2/promise';
import 'dotenv/config';

const categories = [
  { name: 'تطوير الويب', slug: 'web-development', icon: '🌐' },
  { name: 'تطبيقات الهاتف', slug: 'mobile-apps', icon: '📱' },
  { name: 'تصميم واجهات المستخدم', slug: 'ui-ux-design', icon: '🎨' },
  { name: 'التجارة الإلكترونية', slug: 'ecommerce', icon: '🛒' },
  { name: 'تحسين محركات البحث', slug: 'seo', icon: '🔍' },
  { name: 'التسويق الرقمي', slug: 'digital-marketing', icon: '📢' },
  { name: 'حلول السحابة', slug: 'cloud-solutions', icon: '☁️' },
  { name: 'الذكاء الاصطناعي والأتمتة', slug: 'ai-automation', icon: '🤖' },
  { name: 'الأمان السيبراني', slug: 'cybersecurity', icon: '🔒' },
  { name: 'إدارة قواعد البيانات', slug: 'database-management', icon: '🗄️' },
];

const servicesByCategory = {
  'web-development': [
    { name: 'تطوير موقع ويب ثابت', description: 'موقع ويب احترافي بتصميم عصري وسريع', startingPrice: '500 ريال' },
    { name: 'تطوير تطبيق ويب ديناميكي', description: 'تطبيق ويب متقدم مع قاعدة بيانات', startingPrice: '1500 ريال' },
    { name: 'تطوير متجر إلكتروني', description: 'متجر كامل مع نظام الدفع والمخزون', startingPrice: '3000 ريال' },
    { name: 'تطوير لوحة تحكم إدارية', description: 'نظام إدارة متقدم وسهل الاستخدام', startingPrice: '2000 ريال' },
    { name: 'تطوير نظام إدارة المحتوى', description: 'CMS مخصص لإدارة المحتوى بسهولة', startingPrice: '2500 ريال' },
    { name: 'تطوير موقع ويب متجاوب', description: 'موقع يعمل بكفاءة على جميع الأجهزة', startingPrice: '800 ريال' },
    { name: 'تطوير تطبيق ويب تقدمي', description: 'PWA مع إمكانيات عمل بدون إنترنت', startingPrice: '2200 ريال' },
    { name: 'تطوير واجهة برمجية REST', description: 'API قوية وآمنة لتطبيقاتك', startingPrice: '1800 ريال' },
    { name: 'تطوير واجهة برمجية GraphQL', description: 'GraphQL API حديثة وفعالة', startingPrice: '2000 ريال' },
    { name: 'تطوير خادم Node.js', description: 'خادم قوي وقابل للتوسع', startingPrice: '1500 ريال' },
    { name: 'تطوير تطبيق Django', description: 'تطبيق Python قوي وآمن', startingPrice: '1600 ريال' },
    { name: 'تطوير تطبيق Laravel', description: 'تطبيق PHP متقدم وموثوق', startingPrice: '1400 ريال' },
  ],
  'mobile-apps': [
    { name: 'تطوير تطبيق iOS', description: 'تطبيق أيفون احترافي وسلس', startingPrice: '3000 ريال' },
    { name: 'تطوير تطبيق Android', description: 'تطبيق أندرويد عالي الأداء', startingPrice: '2800 ريال' },
    { name: 'تطوير تطبيق متعدد المنصات', description: 'تطبيق واحد لجميع الأنظمة', startingPrice: '4000 ريال' },
    { name: 'تطوير تطبيق React Native', description: 'تطبيق سريع التطوير وفعال', startingPrice: '3500 ريال' },
    { name: 'تطوير تطبيق Flutter', description: 'تطبيق جميل وسريع الأداء', startingPrice: '3200 ريال' },
    { name: 'تطوير تطبيق Xamarin', description: 'تطبيق C# متقدم', startingPrice: '3400 ريال' },
    { name: 'تطوير تطبيق الألعاب', description: 'لعبة موبايل مثيرة وممتعة', startingPrice: '5000 ريال' },
    { name: 'تطوير تطبيق الواقع المعزز', description: 'تطبيق AR تفاعلي ومبتكر', startingPrice: '4500 ريال' },
    { name: 'تطوير تطبيق الواقع الافتراضي', description: 'تطبيق VR غامر ومتقدم', startingPrice: '6000 ريال' },
    { name: 'تطوير تطبيق الدفع', description: 'تطبيق آمن لمعاملات مالية', startingPrice: '4000 ريال' },
    { name: 'تطوير تطبيق الدردشة', description: 'تطبيق تواصل فوري وآمن', startingPrice: '3500 ريال' },
    { name: 'تطوير تطبيق الشبكات الاجتماعية', description: 'منصة تواصل اجتماعي متقدمة', startingPrice: '5000 ريال' },
  ],
  'ui-ux-design': [
    { name: 'تصميم واجهة المستخدم', description: 'تصميم UI احترافي وجذاب', startingPrice: '1000 ريال' },
    { name: 'تصميم تجربة المستخدم', description: 'تجربة UX متميزة وسهلة الاستخدام', startingPrice: '1200 ريال' },
    { name: 'تصميم نموذج أولي', description: 'Prototype تفاعلي للاختبار', startingPrice: '800 ريال' },
    { name: 'تصميم نظام التصميم', description: 'Design System شامل للمشروع', startingPrice: '2000 ريال' },
    { name: 'تصميم تطبيق الهاتف', description: 'تصميم UI/UX لتطبيق موبايل', startingPrice: '1500 ريال' },
    { name: 'تصميم موقع ويب', description: 'تصميم ويب عصري واحترافي', startingPrice: '1200 ريال' },
    { name: 'تصميم لوحة تحكم', description: 'تصميم Dashboard متقدم', startingPrice: '1800 ريال' },
    { name: 'تصميم رسومات', description: 'رسومات احترافية وجذابة', startingPrice: '600 ريال' },
    { name: 'تصميم أيقونات', description: 'مجموعة أيقونات احترافية', startingPrice: '500 ريال' },
    { name: 'تصميم شعار', description: 'شعار احترافي وفريد', startingPrice: '1000 ريال' },
    { name: 'تصميم هوية بصرية', description: 'هوية بصرية شاملة للعلامة التجارية', startingPrice: '2500 ريال' },
    { name: 'تصميم مواد تسويقية', description: 'تصاميم تسويقية احترافية', startingPrice: '800 ريال' },
  ],
  'ecommerce': [
    { name: 'إنشاء متجر إلكتروني', description: 'متجر كامل مع نظام الدفع', startingPrice: '3000 ريال' },
    { name: 'تكامل نظام الدفع', description: 'دمج بوابات الدفع الآمنة', startingPrice: '1500 ريال' },
    { name: 'إدارة المخزون', description: 'نظام إدارة مخزون متقدم', startingPrice: '2000 ريال' },
    { name: 'نظام الشحن والتوصيل', description: 'نظام متكامل للشحن والتوصيل', startingPrice: '2500 ريال' },
    { name: 'نظام إدارة الطلبات', description: 'نظام متقدم لإدارة الطلبات', startingPrice: '1800 ريال' },
    { name: 'نظام التقييمات والتعليقات', description: 'نظام تقييمات موثوق وآمن', startingPrice: '1200 ريال' },
    { name: 'نظام الكوبونات والعروض', description: 'نظام خصومات وعروض متقدم', startingPrice: '1500 ريال' },
    { name: 'نظام الولاء والنقاط', description: 'برنامج ولاء للعملاء', startingPrice: '1800 ريال' },
    { name: 'تطبيق متجر إلكتروني', description: 'تطبيق موبايل للمتجر', startingPrice: '4000 ريال' },
    { name: 'تحسين تحويل المتجر', description: 'زيادة المبيعات والتحويلات', startingPrice: '2000 ريال' },
    { name: 'تحليل سلوك العملاء', description: 'تحليل متقدم لسلوك المشترين', startingPrice: '1500 ريال' },
    { name: 'نظام توصيات المنتجات', description: 'نظام ذكي لتوصيات المنتجات', startingPrice: '2500 ريال' },
  ],
  'seo': [
    { name: 'تحسين محركات البحث SEO', description: 'تحسين ترتيب الموقع في جوجل', startingPrice: '1500 ريال' },
    { name: 'بحث الكلمات المفتاحية', description: 'تحليل شامل للكلمات المفتاحية', startingPrice: '800 ريال' },
    { name: 'تحسين الصفحات الداخلية', description: 'تحسين محتوى الصفحات', startingPrice: '1000 ريال' },
    { name: 'بناء الروابط الخارجية', description: 'بناء روابط عالية الجودة', startingPrice: '1200 ريال' },
    { name: 'تحسين سرعة الموقع', description: 'تحسين أداء وسرعة الموقع', startingPrice: '1000 ريال' },
    { name: 'تحسين تجربة المستخدم', description: 'تحسين UX للترتيب الأفضل', startingPrice: '1200 ريال' },
    { name: 'تحسين الموقع للهاتف', description: 'تحسين Mobile SEO', startingPrice: '900 ريال' },
    { name: 'تحسين الخريطة الموقعية', description: 'إنشاء وتحسين Sitemap', startingPrice: '600 ريال' },
    { name: 'تحسين البيانات المنظمة', description: 'تطبيق Schema Markup', startingPrice: '800 ريال' },
    { name: 'تحليل المنافسين', description: 'تحليل شامل لاستراتيجيات المنافسين', startingPrice: '1000 ريال' },
    { name: 'تقارير SEO الشهرية', description: 'تقارير تفصيلية عن الأداء', startingPrice: '500 ريال' },
    { name: 'استشارة SEO', description: 'استشارة متخصصة في SEO', startingPrice: '1500 ريال' },
  ],
  'digital-marketing': [
    { name: 'إدارة حملات جوجل أدز', description: 'إدارة احترافية لإعلانات جوجل', startingPrice: '2000 ريال' },
    { name: 'إدارة حملات فيسبوك', description: 'إدارة إعلانات فيسبوك وإنستجرام', startingPrice: '1800 ريال' },
    { name: 'التسويق عبر البريد الإلكتروني', description: 'حملات بريد إلكتروني فعالة', startingPrice: '1200 ريال' },
    { name: 'التسويق عبر وسائل التواصل', description: 'إدارة وسائل التواصل الاجتماعي', startingPrice: '1500 ريال' },
    { name: 'إنشاء محتوى تسويقي', description: 'محتوى احترافي وجذاب', startingPrice: '1000 ريال' },
    { name: 'التسويق بالمحتوى', description: 'استراتيجية محتوى متقدمة', startingPrice: '1800 ريال' },
    { name: 'التسويق بالفيديو', description: 'إنتاج فيديوهات تسويقية احترافية', startingPrice: '2500 ريال' },
    { name: 'التسويق بالتسلسل', description: 'حملات تسويق بالتسلسل الذكي', startingPrice: '1500 ريال' },
    { name: 'تحليل البيانات التسويقية', description: 'تحليل شامل لنتائج الحملات', startingPrice: '1200 ريال' },
    { name: 'استراتيجية تسويقية شاملة', description: 'خطة تسويقية متكاملة', startingPrice: '3000 ريال' },
    { name: 'إدارة سمعة العلامة التجارية', description: 'إدارة السمعة الرقمية', startingPrice: '2000 ريال' },
    { name: 'استشارة تسويقية', description: 'استشارة متخصصة في التسويق الرقمي', startingPrice: '1500 ريال' },
  ],
  'cloud-solutions': [
    { name: 'استضافة سحابية', description: 'استضافة آمنة وموثوقة', startingPrice: '500 ريال' },
    { name: 'نسخ احتياطية سحابية', description: 'نسخ احتياطية تلقائية وآمنة', startingPrice: '600 ريال' },
    { name: 'إدارة السحابة', description: 'إدارة متقدمة للموارد السحابية', startingPrice: '1200 ريال' },
    { name: 'نقل البيانات للسحابة', description: 'نقل آمن للبيانات', startingPrice: '1500 ريال' },
    { name: 'تحسين أداء السحابة', description: 'تحسين الأداء والتكاليف', startingPrice: '1000 ريال' },
    { name: 'حل السحابة الهجينة', description: 'حل سحابة هجينة متقدم', startingPrice: '2500 ريال' },
    { name: 'خدمات AWS', description: 'حلول AWS متقدمة', startingPrice: '2000 ريال' },
    { name: 'خدمات Azure', description: 'حلول Azure متكاملة', startingPrice: '2000 ريال' },
    { name: 'خدمات Google Cloud', description: 'حلول Google Cloud متقدمة', startingPrice: '2000 ريال' },
    { name: 'إدارة الحاويات Docker', description: 'إدارة Docker والحاويات', startingPrice: '1500 ريال' },
    { name: 'إدارة Kubernetes', description: 'إدارة متقدمة لـ Kubernetes', startingPrice: '2000 ريال' },
    { name: 'استشارة السحابة', description: 'استشارة متخصصة في الحلول السحابية', startingPrice: '1500 ريال' },
  ],
  'ai-automation': [
    { name: 'تطوير نموذج تعلم آلي', description: 'نموذج ML متقدم ودقيق', startingPrice: '3000 ريال' },
    { name: 'تطوير chatbot ذكي', description: 'روبوت محادثة ذكي وفعال', startingPrice: '2500 ريال' },
    { name: 'معالجة اللغة الطبيعية', description: 'معالجة NLP متقدمة', startingPrice: '2500 ريال' },
    { name: 'رؤية الحاسوب', description: 'تحليل الصور والفيديو', startingPrice: '3000 ريال' },
    { name: 'التعرف على الأنماط', description: 'كشف الأنماط والشذوذ', startingPrice: '2500 ريال' },
    { name: 'التنبؤ والتحليل', description: 'نماذج تنبؤية متقدمة', startingPrice: '2800 ريال' },
    { name: 'أتمتة العمليات', description: 'أتمتة ذكية للعمليات', startingPrice: '2000 ريال' },
    { name: 'روبوتات العمليات', description: 'RPA متقدمة وفعالة', startingPrice: '3000 ريال' },
    { name: 'التعرف على الوجوه', description: 'نظام تعرف على الوجوه', startingPrice: '2500 ريال' },
    { name: 'معالجة الكلام', description: 'تحويل الكلام لنص والعكس', startingPrice: '2000 ريال' },
    { name: 'التوصيات الذكية', description: 'نظام توصيات ذكي', startingPrice: '2500 ريال' },
    { name: 'استشارة AI', description: 'استشارة متخصصة في الذكاء الاصطناعي', startingPrice: '2000 ريال' },
  ],
  'cybersecurity': [
    { name: 'اختبار الاختراق', description: 'اختبار أمان شامل', startingPrice: '3000 ريال' },
    { name: 'تقييم الأمان', description: 'تقييم شامل لأمان النظام', startingPrice: '2500 ريال' },
    { name: 'حماية من البرامج الضارة', description: 'حماية متقدمة من البرامج الضارة', startingPrice: '1500 ريال' },
    { name: 'جدار حماية متقدم', description: 'جدار حماية ذكي ومتقدم', startingPrice: '2000 ريال' },
    { name: 'تشفير البيانات', description: 'تشفير آمن للبيانات', startingPrice: '1500 ريال' },
    { name: 'إدارة الهويات والوصول', description: 'نظام IAM متقدم', startingPrice: '2000 ريال' },
    { name: 'مراقبة الأمان', description: 'مراقبة 24/7 للأمان', startingPrice: '2500 ريال' },
    { name: 'استجابة الحوادث', description: 'فريق استجابة سريع', startingPrice: '3000 ريال' },
    { name: 'تدريب الأمان', description: 'تدريب موظفين على الأمان', startingPrice: '1500 ريال' },
    { name: 'سياسات الأمان', description: 'وضع سياسات أمان شاملة', startingPrice: '2000 ريال' },
    { name: 'الامتثال الأمني', description: 'ضمان الامتثال للمعايير', startingPrice: '2500 ريال' },
    { name: 'استشارة الأمان', description: 'استشارة متخصصة في الأمان السيبراني', startingPrice: '2000 ريال' },
  ],
  'database-management': [
    { name: 'تصميم قاعدة بيانات', description: 'تصميم قاعدة بيانات محسنة', startingPrice: '1500 ريال' },
    { name: 'إدارة قاعدة البيانات', description: 'إدارة متقدمة لقاعدة البيانات', startingPrice: '1200 ريال' },
    { name: 'تحسين الأداء', description: 'تحسين أداء قاعدة البيانات', startingPrice: '1500 ريال' },
    { name: 'النسخ الاحتياطية', description: 'نسخ احتياطية آمنة وموثوقة', startingPrice: '1000 ريال' },
    { name: 'استرجاع البيانات', description: 'استرجاع آمن للبيانات المفقودة', startingPrice: '2000 ريال' },
    { name: 'نقل البيانات', description: 'نقل آمن للبيانات', startingPrice: '1500 ريال' },
    { name: 'تنظيف البيانات', description: 'تنظيف وتحسين جودة البيانات', startingPrice: '1200 ريال' },
    { name: 'تحليل البيانات', description: 'تحليل متقدم للبيانات', startingPrice: '1500 ريال' },
    { name: 'تصور البيانات', description: 'تصور احترافي للبيانات', startingPrice: '1200 ريال' },
    { name: 'قاعدة بيانات NoSQL', description: 'إدارة قواعد NoSQL', startingPrice: '1500 ريال' },
    { name: 'قاعدة بيانات العلاقات', description: 'إدارة قواعد SQL متقدمة', startingPrice: '1400 ريال' },
    { name: 'استشارة قواعد البيانات', description: 'استشارة متخصصة في قواعد البيانات', startingPrice: '1500 ريال' },
  ],
};

async function seedDatabase() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);

  try {
    console.log('بدء ملء قاعدة البيانات...');

    // Insert categories
    for (const category of categories) {
      const [result] = await connection.execute(
        'INSERT INTO service_categories (name, slug, icon, displayOrder) VALUES (?, ?, ?, ?)',
        [category.name, category.slug, category.icon, categories.indexOf(category)]
      );
      
      const categoryId = result.insertId;
      
      // Insert services for this category
      const services = servicesByCategory[category.slug] || [];
      for (let i = 0; i < services.length; i++) {
        const service = services[i];
        await connection.execute(
          'INSERT INTO services (categoryId, name, slug, description, features, startingPrice, displayOrder) VALUES (?, ?, ?, ?, ?, ?, ?)',
          [
            categoryId,
            service.name,
            service.name.toLowerCase().replace(/\s+/g, '-'),
            service.description,
            JSON.stringify(['ميزة 1', 'ميزة 2', 'ميزة 3']),
            service.startingPrice,
            i
          ]
        );
      }
      
      console.log(`✓ تم إضافة فئة: ${category.name} مع ${services.length} خدمة`);
    }

    console.log('✓ تم ملء قاعدة البيانات بنجاح!');
    console.log('✓ تم إضافة 10 فئات و 120 خدمة');
  } catch (error) {
    console.error('خطأ في ملء قاعدة البيانات:', error);
  } finally {
    await connection.end();
  }
}

seedDatabase();
